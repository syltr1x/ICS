key = '0xMS4wLjM='
import requests as r
import customtkinter
import json
import logic
import os

customtkinter.set_appearance_mode("dark")
customtkinter.set_default_color_theme("red")

self = customtkinter.CTk()
self.geometry("1100x400")
self.title("Home | Punto Diesel")
self.configure()
# frame = custom.App(master=app)
# frame.grid(row=0, column=1, padx=(15, 0), pady=10, sticky="ns")

def pepe(marco):
    print(marco)

list1 = ["manzana", "cigueñal", "uva"]
list2 = ["merca", "marihuana", "jeringas"]

# carlos = customtkinter.CTkComboBox(self, values=list1, command=pepe)
# carlos.grid(row=1, column=1)
# pp = customtkinter.CTkLabel(self, text="cigueñal")
# pp.grid(row=1, column=2)

dato = 'cigueñal'
data = str(logic.get_product("item", dato, "strict"))
data = json.loads(data[:-1][1:].replace("'", '"'))

item_label = customtkinter.CTkLabel(self, text='Nombre de Producto :', fg_color="gray30", corner_radius=5).grid(row=0, column=0, padx=(30, 5), pady=(15, 5))
item_data_label = customtkinter.CTkLabel(self, text=data["item"]).grid(row=0, column=1, padx=(5, 30), pady=(15, 5))

price_label = customtkinter.CTkLabel(self, text='Precio/u :', fg_color="gray30", corner_radius=5).grid(row=1, column=0, padx=(30, 5), pady=(15, 5))
price_data_label = customtkinter.CTkLabel(self, text=f'${data["price"]}').grid(row=1, column=1, padx=(5, 30), pady=(15, 5))
        
stock_label = customtkinter.CTkLabel(self, text='Stock :', fg_color="gray30", corner_radius=5).grid(row=2, column=0, padx=(30, 5), pady=(15, 5))
stock_data_label = customtkinter.CTkLabel(self, text=data["stock"]).grid(row=2, column=1, padx=(5, 30), pady=(15, 5))


self.mainloop()